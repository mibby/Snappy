﻿using System;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.Game.Character;

namespace Snappy.Managers;

public unsafe class ReconstructGlamourer
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct WeaponModelData
    {
        public ushort ModelBase;
        public ushort ModelVariant;
        public ushort ModelSet;
        public ushort Unknown;
    }

    [StructLayout(LayoutKind.Sequential)]
    public unsafe struct CharacterDrawObject
    {
        public fixed byte Unknown[0x160];
        public fixed byte EquipmentBlock[13 * 16]; // 208 bytes for equipment
        // At offset 0x1C0: WeaponModelData[2]
    }

    public unsafe string ReconstructGlamourerStringFromMemory(ICharacter character)
    {
        if (character == null || character.Address == IntPtr.Zero)
            return string.Empty;

        var chr = (Character*)character.Address;

        // Customize (26 bytes)
        byte[] customize = new byte[26];
        for (int i = 0; i < 26; i++)
            customize[i] = chr->DrawData.CustomizeData[i];

        // Equipment (11 × 4 bytes = 44 bytes)
        var drawObject = chr->GameObject.DrawObject;
        if (drawObject == null)
            return string.Empty;

        var drawData = (CharacterDrawObject*)drawObject;

        byte[] equipment = new byte[11 * 4];
        for (int i = 0; i < 11; i++)
        {
            var ptr = (byte*)drawData->EquipmentBlock + i * 16;
            uint modelId = *(uint*)ptr;
            byte variant = *(ptr + 4);
            byte dye = *(ptr + 5);

            var modelBytes = BitConverter.GetBytes(modelId);
            equipment[i * 4 + 0] = modelBytes[0];
            equipment[i * 4 + 1] = modelBytes[1];
            equipment[i * 4 + 2] = modelBytes[2];
            equipment[i * 4 + 3] = dye;
        }

        // Weapon models
        var weaponData = (WeaponModelData*)((byte*)drawData + 0x1C0);

        ushort mhBase = weaponData[0].ModelBase;
        ushort mhVariant = weaponData[0].ModelVariant;
        ushort mhSet = weaponData[0].ModelSet;

        ushort ohBase = weaponData[1].ModelBase;
        ushort ohVariant = weaponData[1].ModelVariant;
        ushort ohSet = weaponData[1].ModelSet;

        // Optional metadata
        float[] customizePlus = Array.Empty<float>();
        int customizePlusVersion = 0;
        int writeProtected = 0;
        int automation = 0;
        string tag = string.Empty;
        int fileVersion = 0;

        return GlamourerBase64Builder.CreateBase64V6(
            customize,
            equipment,
            customizePlusVersion,
            customizePlus,
            writeProtected,
            automation,
            tag,
            fileVersion,
            mhBase, mhVariant, mhSet,
            ohBase, ohVariant, ohSet
        );
    }
}
