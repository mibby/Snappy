﻿using OtterGui.Log;
using System;
using System.IO;
using System.IO.Compression;
using System.Text;

public static class GlamourerBase64Builder
{
    public static string CreateBase64V6(
        byte[] customize,
        byte[] equipment,
        int customizePlusVersion,
        float[] customizePlus,
        int writeProtected,
        int automation,
        string tag,
        int fileVersion,
        ushort mhBase, ushort mhVariant, ushort mhSet,
        ushort ohBase, ushort ohVariant, ushort ohSet)
    {
        using var rawStream = new MemoryStream();
        using var writer = new BinaryWriter(rawStream);

        writer.Write((byte)6); // version
        writer.Write(customize);
        writer.Write(equipment);
        writer.Write(customizePlusVersion);
        writer.Write(customizePlus.Length);
        foreach (var f in customizePlus)
            writer.Write(f);
        writer.Write(writeProtected);
        writer.Write(automation);

        var tagBytes = System.Text.Encoding.UTF8.GetBytes(tag);
        writer.Write(tagBytes.Length);
        writer.Write(tagBytes);

        writer.Write(fileVersion);

        writer.Write(mhBase);
        writer.Write(mhVariant);
        writer.Write(mhSet);
        writer.Write(ohBase);
        writer.Write(ohVariant);
        writer.Write(ohSet);

        var uncompressed = rawStream.ToArray();
        var adler = Adler32(uncompressed);
        Logger.Debug($"Uncompressed payload length: {uncompressed.Length}");


        using var compressedStream = new MemoryStream();

        // Write zlib header
        compressedStream.WriteByte(0x78);
        compressedStream.WriteByte(0x9C);

        // Deflate-compress the payload
        using (var deflate = new DeflateStream(compressedStream, CompressionLevel.Optimal, true))
        {
            deflate.Write(uncompressed, 0, uncompressed.Length);
        } // Disposed here, which flushes all data into compressedStream

        // Write Adler-32 checksum
        compressedStream.WriteByte((byte)((adler >> 24) & 0xFF));
        compressedStream.WriteByte((byte)((adler >> 16) & 0xFF));
        compressedStream.WriteByte((byte)((adler >> 8) & 0xFF));
        compressedStream.WriteByte((byte)(adler & 0xFF));

        return Convert.ToBase64String(compressedStream.ToArray());
    }

    private static uint Adler32(byte[] data)
    {
        const uint MOD_ADLER = 65521;
        uint a = 1, b = 0;

        foreach (var t in data)
        {
            a = (a + t) % MOD_ADLER;
            b = (b + a) % MOD_ADLER;
        }

        return (b << 16) | a;
    }
}
