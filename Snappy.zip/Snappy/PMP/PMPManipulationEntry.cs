using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snappy.PMP
{
    internal class PMPManipulationEntry
    {
        public string Type { get; set; }
        public object Manipulation { get; set; }
    }
}
